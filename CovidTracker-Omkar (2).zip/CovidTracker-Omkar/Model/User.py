class User:
    def __init__(self,name,mobile_no,pincode):
        self.name=name
        self.mobile_no=mobile_no
        self.pincode=pincode