from Model.User import User


class Healthworker(User):
    def __init__(self, name, phonenumber, pincode):
        # self.name = name
        # self.phonenumber = phonenumber
        # self.pincode = pincode
        super().__init__(name, phonenumber, pincode)

    def update_covid_result(self, result):
        self.result = result

    def set_result(self, result):
        return result
