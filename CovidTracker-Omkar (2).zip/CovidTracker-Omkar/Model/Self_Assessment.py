class Self_Assment:
    def __init__(self, userid, symptoms, travelhisotry, conatct_patients):
        self.userid = userid
        self.symptoms = symptoms
        self.travelhisotry = travelhisotry
        self.conatct_patients = conatct_patients

