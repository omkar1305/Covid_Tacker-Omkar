from Services.User_Manager import User_Manager
from Model.User import User
from Model.Self_Assessment import Self_Assment


class Driver:
    user_manager = User_Manager()
    user_manager.addUsers(User('A', '8830987654', '1111'))
    user_manager.addUsers(User('A', '88309876543', '1234'))
    user_manager.addUsers(User('A', '8830987652', '1111'))
    user_manager.addUsers(User('A', '8830987651', '1111'))

    #Mobile no. has been taken user_id and will be unique

    user_manager.self_assessment(Self_Assment("8830987654",["fever","cold","cough"],True,True))

    user_manager.update_covid_result('8830987654','positive')
    user_manager.update_covid_result('8830987652', 'positive')
    user_manager.update_covid_result('8830987651', 'positive')

    user_manager.get_zone_info('1111')




