
class User_Manager:
    def __init__(self):
        self.user_map = {}
        self.covid_map = {}

    def addUsers(self, user):
        self.user_map[user.mobile_no] = user

    # def add_Assesment(self,self_aasessment):

    def self_assessment(self, info):
        ctr_symptoms = 0
        ctr_symptoms_flag = False
        while ctr_symptoms < len(info.symptoms):
            ctr_symptoms += 1
        if ctr_symptoms == 1:
            ctr_symptoms_flag = True
        # elif ctr_symptoms > 1:
        #     ctr_symptoms = 2

        if info.travelhisotry == False or info.conatct_patients == False or ctr_symptoms == 0:
            print('{"riskPercentage": 5}')
            return {"riskPercentage": 5}
        elif (info.travelhisotry or info.conatct_patients) and ctr_symptoms_flag:
            print('{"riskPercentage": 50}')
            return {"riskPercentage": 50}
        elif (info.travelhisotry or info.conatct_patients) and (ctr_symptoms == 2):
            print('{"riskPercentage": 75}')
            return {"riskPercentage": 75}
        elif (info.travelhisotry or info.conatct_patients) and (ctr_symptoms > 2):
            print('{"riskPercentage": 95}')
            return {"riskPercentage": 95}

    def update_covid_result(self, user_id, result):
        self.covid_map[user_id] = result
        print('{"updated":true}')

    def get_zone_info(self, zipcode):
        patients = 0
        for i in self.covid_map:
            if self.covid_map[i] == 'positive':
                if zipcode == self.user_map[i].pincode:
                    patients += 1
        if patients < 5:
            print(' {"numCases":', patients, '"zoneType":"ORANGE"}')
        else:
            print(' {"numCases":', patients, '"zoneType":"RED"}')
